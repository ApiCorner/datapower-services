
var hm = require('header-metadata');
var crypto = require('crypto');
// to use xpath, require the 'transform' module
var transform = require('transform');
var tiempoActual = new Date().getTime();
var all_Headers = hm.current.headers;
//get the cookie header
var authorizationHeader = hm.original.get('Authorization');
try {
if (authorizationHeader) {
	var authorizationValue = authorizationHeader.substring(authorizationHeader.indexOf('Basic')+6, authorizationHeader.length).trim();
	//decode authorization header
	var buffer = new Buffer(authorizationValue,"base64");
	console.info("User Credentials (after base64): "+ buffer.toString());
	//split the token in the header
	var authTokens = buffer.toString().split(':');
	console.info('authTokens:' + authTokens.toString());
} else {
	throw new Error('No Authorization Header');
	//session.reject('No Authorization Header'); 
}
//var username = hm.current.get('username');
var username = authTokens[0];
//en el password viaja el token
//var password = hm.current.get('password');
var password = authTokens[1];
//Comprobar que no está vacio
if (!password){
	throw new Error('No Password in Authorization Header');
}
else //se continua con el proceso
{
  var token = password;
  var decodeToken = new Buffer(token, 'base64').toString('utf8');
  //parseo del token en diferentes variable
  var claims = decodeToken.split("#");
  var ID = claims[0];
  var IP = claims[1];
  var FC = claims[2];
  //If (!claims[3]){
      //Evita error en la creacion del buffer
      var xmlString = new Buffer(claims[3], 'base64').toString('utf8');
      console.log("========El xmlString es: "+xmlString);
  //}
  var TC = claims[4];
  var VT = claims[5];
  var ET = claims[6];
  var XML_cifrado = claims[7];
  var TF = claims[8];
  var signature = claims[9];
  if(!ID||!IP||!FC||!xmlString||!TC||!ET||!XML_cifrado||!TF||!signature){
    //Falta alguno de los campos luego el token no es valido
    console.log("El token "+decodeToken);
	throw new Error('Malformed Token');
  }
  else {
    //****************************************verificar que el token no ha expirado
    console.log("============El tiempoActual es: "+tiempoActual);
    console.log("============El campo FC es:    "+FC);

    //if (tiempoActual < FC){
    if (FC < tiempoActual){
      //By making the comparison “current time in milliseconds < expiration time”, it can be confirmed that the token has not expired.
		throw new Error('Expired Token');
    }
    else //Se continua con el proceso
    {
      //buscar en el XML el usuario y compararlo con el de la cabecera
      console.log("fase de buscar uid en xmlString");
      var domTree = undefined;
      var usuarioXML;
      try {
        // use XML.parse() to parse the xmlString into a DOM tree structure
        domTree = XML.parse(xmlString);
        console.log(domTree);
      } catch (error) {
        // there was an error while parsing the XML string
        console.error('error parsing XML string ' + error);
        throw error;
      }
      transform.xpath('/tokenDefinition/userID/text()', domTree, function(error, userNodeList) {
        if (error) {
          console.error('error while executing /tokenDefinition/userID/text() xpath - ' + error);
          throw error;
        }
        else {
          //usuarioXML = userNodeList; // userNodeList is DOM NodeList structure
          var result = "";
          for (var c=0; c<userNodeList.length; c++) {
            result += userNodeList.item(c).textContent;
          }
          var usuarioXML = result.toString();
          //console.log("El username es: "+username);
          //console.log("=======El usuarioXML es: "+usuarioXML);
          //console.log("El resultado de la comparacion es:  "+usuarioXML==result);
          if (usuarioXML != username){
			throw new Error('UserId mismatch');
            }
            else {
              //Se continua con el proceso
              //verificar la firma
              var cert = ET.concat(TF); //El objeto cert con el que comprobar la firma se llama igual que el emisor+Algoritmo
              //*********************************Para pruebas se pone un nombre fijo
              //var cert = "EjemploX509-2048bits";
              var sep = "#";
              console.log("==========El campo 3 del token parametro es:  "+claims[3]);
              var tokenSinFirma = ID.concat(sep,IP,sep,FC,sep,claims[3],sep,TC,sep,VT,sep,ET,sep,XML_cifrado,sep,TF,sep);
              //<xsl:variable name="tokenHash" select="dp:hash('http://www.w3.org/2000/09/xmldsig#sha1',$Token_Without_Sign)"/>
              console.log("==========El token sin firma es:  "+tokenSinFirma);
              var hash = crypto.createHash('sha1');
              var tokenHash = hash.update(tokenSinFirma).digest('base64');
              console.log("==========El tokenHash es:  "+tokenHash);
              //<xsl:variable name="verify-result_Token" select="dp:verify($signMechanism,$tokenHash,$Firma_Token,$key)"/>
              var verify = crypto.createVerify('rsa-sha1');
              console.log("==========La firma es:  "+signature);
              //verify.update(tokenHash).verify(key, signature, function(error) {
              verify.update(tokenSinFirma).verify(cert, signature, function(error) {
              if (error) {
                console.error("verification fail: "+error);
				throw new Error('Token signature verification failed');

              }
              else
              {
				  var ctx = session.name('TVS') || session.createContext('TVS');
				  ctx.setVar('issuer', ET);
				  ctx.setVar('userID', username);
				  ctx.setVar('sessionId', ID);
			  /*
                session.output.write( {
                  //  username: username,
                  //  password: password,
                  //  decodeToken: decodeToken,
                  Emisor: ET,
                  Algoritmo: TF,
                  Firma: signature,
                  XML: xmlString
                });
                hm.response.set('API-Authenticated-Credential',username);
			  */
               }
         });
		  var ctx = session.name('TVS') || session.createContext('TVS');
		  ctx.setVar('issuer', ET);
		  ctx.setVar('userID', username);
		  ctx.setVar('sessionId', ID);
        }
      }
    });
  }
}
}
} catch (error) {
	console.error('Catch Error ' + error);
	throw error;
}

